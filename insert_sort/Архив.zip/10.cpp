#include <stdio.h>
#include <ctype.h>
#include <string.h>
char gl[]="aeiouy";
int isvowel(char a){
    for (int j=0;j<6;++j){
        if (a==gl[j]) return 1;
    }
    return 0;
}
int isalpha(char a){
    return (a-'a'>-1 && a-'a'<26);
}
int main() {
    char a[10000];
    char* txt=a;
    char slogi[1000][5]={'\0'};
    char slog[10]={'\0'};
    int num=0;
    int cnt=0;
    while(1){
        gets_s(txt,1000);
        if (txt[0]=='\0') break;
        for (int i=0;txt[i];i++){
            if (isvowel(txt[i])){
                for (int i=0;slog[i];i++){
                    slogi[num][i]=slog[i];
                    slog[i]='\0';
                }
                slogi[num][cnt]=txt[i];
                cnt=0;
                num++;
            }else{
                if (!isalpha(txt[i]) && slog[0]!='\0'){
                    for (int i=0;slog[i];i++) {
                        slogi[num-1][strlen(slogi[num-1])+i]=slog[i];
                        slog[i]='\0';
                        cnt=0;
                    }
                }
                slog[cnt]=txt[i];
                cnt++;
            }
        }
        if (slog[0]!='\0') for (int i=0;slog[i];i++){
            slogi[num-1][strlen(slogi[num-1])+i]=slog[i];
            slog[i]='\0';
            cnt=0;
        }
        slogi[num-1][strlen(slogi[num-1])]='\n';
    }
    for (int i=0;i<num;++i){
        if (slogi[i+1][0]==' ' || i==num-1 || slogi[i][strlen(slogi[i])-1]=='\n') printf("%s",slogi[i]);
        else printf("%s-",slogi[i]);
    }
    printf("\n");
    return 0;
}
